# Semana No. 15: Ejercicio 2 Julio Rafael Guevara Gómez
print("Ejercicio no. 2")

X = 0
Y = 0

# Funciones de movimiento
def MoverHaciaArriba():
    global Y
    Y += 1

def MoverHaciaAbajo():
    global Y
    Y -= 1

def MoverHaciaLaDerecha():
    global X
    X += 1

def MoverHaciaLaIzquierda():
    global X
    X -= 1

# Función para mostrar el menú
def mostrar_menu():
    print("Semana No. 12: Ejercicio 2")
    print("Menú de movimiento:")
    print("a. Sube")
    print("b. Baja")
    print("c. Izquierda")
    print("d. Derecha")
    print("e. Salir")

# Función principal
def main():
    global X, Y
    mostrar_menu()
    while True:
        opcion = input("Ingrese su opción: ")
        if opcion == "a":
            MoverHaciaArriba()
        elif opcion == "b":
            MoverHaciaAbajo()
        elif opcion == "c":
            MoverHaciaLaIzquierda()
        elif opcion == "d":
            MoverHaciaLaDerecha()
        elif opcion == "e":
            print("Coordenadas finales del personaje:", X, ",", Y)
            break
        else:
            print("Opción no válida.")
        mostrar_menu()

# Ejecutar el programa
main()
